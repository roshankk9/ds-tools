var json2csv = require('json2csv')
var fs = require('fs')
var forecasts = require('./forecasts.json')

json2csv({ data:forecasts}, function(error, csv){

	fs.writeFile('forecasts.csv', csv);
})