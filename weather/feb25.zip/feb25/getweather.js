var request = require('request');
var yargs = require('yargs')
var fs = require('fs');

var forecasts = require('./forecasts.json')

var args = yargs.argv;

//var url="http://api.openweathermap.org/data/2.5/weather?q="+args.city+"&APPID=6eca3756939815795f28b384d1578d82&units=imperial";
var url="http://api.openweathermap.org/data/2.5/forecast?q="+args.city+"&APPID=6eca3756939815795f28b384d1578d82&units=imperial";

request({url:url, json:true},function(error, response, body){

//console.log("Current temperature of city "+args.city +" is "+body.main.temp +" Degrees");

var time=0;
body.list.forEach(function(measurement)
{
	//console.log(measurement.main.temp)

		info={city:args.city, time:time, date:measurement.dt_txt, temp:measurement.main.temp}
		forecasts.push(info);
		time = time + 3;

		//console.log(info)
})


Jsonarray = JSON.stringify(forecasts);

fs.writeFile('forecasts.json', Jsonarray);

	//for(i=0; i<body.list.length; i++)
	//{
	//	console.log(body.list[i].main.temp)
	//}
})
